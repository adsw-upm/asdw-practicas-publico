package es.upm.dit.adsw.p2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import edu.princeton.cs.algs4.DijkstraSP;
import edu.princeton.cs.algs4.DirectedEdge;
import edu.princeton.cs.algs4.EdgeWeightedDigraph;
import es.upm.dit.adsw.movies.Movie;

public class GraphLoader {
	/**
	 * Grafo que representará las conexiones entre actores a través de las películas
	 * donde han colaborado.
	 */
	public EdgeWeightedDigraph g;
	/**
	 * int que nos indicará cual será el siguiente vértice que queremos añadir al
	 * grafo.
	 */
	int actorsCount = 0;

	/**
	 * Mapa de tipo Map<String, Integer> Sirve para buscar por el String que
	 * representa el nombre del actor y poder obtener el Integer que lo representa
	 * en el modelo de grafos. Este mapa nos será muy útil para poder saber qué
	 * actor representa qué nodo. Y poder obtener el camino entre dos actores.
	 */
	public Map<String, Integer> actorsMap = new HashMap<String, Integer>();

	/**
	 * Mapa de tipo Map<DirectedEdge, Movie> Dado un DirectedEdge se puede obtener
	 * la película donde colaboraron ambos actores. Este mapa nos será muy útil para
	 * poder saber qué actor representa qué nodo. Y poder obtener el camino entre
	 * dos actores.
	 */
	public Map<DirectedEdge, Movie> moviesMap = new HashMap<DirectedEdge, Movie>();

	/**
	 * Obtiene el diccionario invertido de Actores. La clase GraphLoader tiene el
	 * mapa Map<String, Integer> actorsMap Y queremos obtener el mapa inverso
	 * Map<Integer, String>, para hacer búsquedas de que número es qué actor.
	 * 
	 * @return devuelve un mapa Map<Integer, String>
	 */
	public Map<Integer, String> getActorsMapInverted() {
		return this.actorsMap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));
	}

	/**
	 * Devuelve el número de actores distintos que encontramos en un fichero de
	 * datos de cast pasado como parámetro
	 * 
	 * @param cast dada el path de los actores
	 * @return un long diciendo todos los actores no repetidos que encontramos en el
	 *         fichero de entrada
	 * @throws IOException Lanza excepción si la ruta no es correcta.
	 */
	public static long actorsCount(String cast) throws IOException {
		return Files.lines(Paths.get(cast)).flatMap(s -> Arrays.stream(s.split("\t")).skip(1)).distinct().count();
	}

	/**
	 * Devuelve un Integer devolviendo el valor que representa al actor en el modelo
	 * de grafos. Esa información la guardaremos en this.actorsMap Si el actor ya
	 * existe, devolvemos el valor. Si no existe, deberá asignarle el siguiente
	 * entero (actorsCount) y guardarlo en ActorMap
	 * 
	 * @param actor un String con el nombre del actor
	 * @return devuelve el Integer que representa el actor en el modelo de grafos
	 */
	protected Integer getActorID(String actor) {
		// TODO
		return null;
	}

	/**
	 * Este método añade dos DirectedEdge al grafo que tenemos en el atributo de
	 * clase this.g con los actores pasados como parámetro OJO! queremos un
	 * DirectedEdge, es decir, no es lo mismo un DirectedEdge entre Actor1 y Actor2,
	 * que de Actor2 a Actor1 Por lo tanto tendremos que crear dos DirectedEdge
	 * Además deberíamos guardar en this.movieMap el arco que representa qué
	 * película para luego poder buscar el camino.
	 * 
	 * @param actor1 String actor origen del arco
	 * @param actor2 String actor destino del arco
	 * @param movie  película en la que han colaborado.
	 */
	protected void addEdge(String actor1, String actor2, Movie movie) {
		// TODO
	}

	/**
	 * Método que devuelve todas las posibles de combinaciones entre actores en una
	 * película. Devolviendo las combinaciones en una Lista de arrays de String de
	 * dos posiciones.
	 * 
	 * @param movie La película que queremos conseguir la combinacion de actores.
	 * @return List<String[]> Lista de arrays de String de dos posiciones.
	 */
	protected List<String[]> getActorsPairs(Movie movie) {
		// TODO
		return null;
	}

	/**
	 * Método que carga en this.g todos arcos del grafo que representa las
	 * relaciones de actores de una lista de películas El modelo es: los vértices
	 * son los actores, los arcos son las películas en las que ha colaborado un
	 * actor con otro en una película. El grafo debe de estar cargado en this.g
	 * Además se deben actualizar los mapas this.actorsMap y this.moviesMap para
	 * poder realizar las búsquedas del camino
	 * 
	 * @param movies      List<Movie> lista de películas del modelo del laboratorio
	 *                    y práctica 1
	 * @param actorNumber Número de actores distintos dentro del cast
	 */
	public void loadGraph(List<Movie> movies, int actorNumber) {
		// TODO
	}

	/**
	 * Este es un método que calcula en camino mínimo colaboraciones entre dos actores, indicando la secuencia 
	 * de colaboraciones de actores y en que películas.
	 * 
	 * @param ActorSource actor origen en la búsqueda del camino
	 * @param ActorDestination actor destino en la búsqueda del camino
	 * @return nos devolverá la secuencia de actores que han colaborado entre películas, 
	 * y las películas en las que han colaborado cada par de actores
	 */
	public List<String> getShortestPath(String ActorSource, String ActorDestination) throws Exception {
		// TODO
		return null;
	}

}